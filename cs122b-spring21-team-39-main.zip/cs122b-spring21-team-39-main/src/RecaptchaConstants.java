
public class RecaptchaConstants {

    public static final String SECRET_KEY ="6Ld9B8UaAAAAADSPyMDavqlssjw5i8sNy56rcBxK";

}
