public interface MySqlAuth {
    public final String loginurl = "jdbc:mysql:///moviedb?autoReconnect=true&useSSL=false";
    public final String username = "mytestuser";
    public final String password = "My6$Password";
}